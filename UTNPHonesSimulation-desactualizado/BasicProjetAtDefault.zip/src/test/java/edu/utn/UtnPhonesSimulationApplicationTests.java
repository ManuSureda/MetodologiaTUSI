package edu.utn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtnPhonesSimulationApplicationTests {

	@Test
	void contextLoads() {
	}

}
