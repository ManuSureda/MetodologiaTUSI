package edu.utn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UtnPhonesSimulationApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtnPhonesSimulationApplication.class, args);
	}

}
